package nl.ru.ai.exercise5;

public class Attempt
{
  public int row;
  public int col;
  public Attempt(int row, int col)
  {
    this.row=row;
    this.col=col;
  }

}
