package nl.ru.ai.exercise5;

public class Candidate {
	public Attempt attempt;
	public int parentCandidate;
	public Puzzle puzzle;

	public Candidate(Attempt attempt, int parentCandidate) {
		this.attempt = attempt;
		this.parentCandidate = parentCandidate;
	}

	public Candidate(Puzzle puzzle, int parentCandidate) {
		this.puzzle = puzzle;
		this.parentCandidate = parentCandidate;
	}
}
