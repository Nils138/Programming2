package nl.ru.ai.exercise5;

import java.util.ArrayList;

public class Puzzle {
	public int[][] board = new int[Exercise5.width][Exercise5.height];
	public Pos empty;

	/**
	 * checks whether the given puzzle already occurs in the arraylist, therefore
	 * being a duplicate
	 * 
	 * @param puzzle
	 * @param i
	 * @param candidates
	 * @return false if it's original, true if it's a duplicate
	 */

	// this function used to work based on a separate array which stored all new
	// candidates, but now it checks previous candidates.
	static boolean duplicate(Puzzle puzzle, int i, ArrayList<Candidate> candidates) {
		assert candidates != null : "List should be initialized";
		assert i < candidates.size() && i >= 0 : "index out of bounds";
		assert puzzle != null : "Puzzle should be initialized";
		for (int j = 0; j < puzzle.board.length; j++) {
			for (int k = 0; k < puzzle.board[j].length; k++) {
				if (puzzle.board[j][k] != candidates.get(i).puzzle.board[j][k]) {
					return false;
				}
			}
		}
		return true;
	}

	public Puzzle(int[][] board, Pos pos) {
		this.board = board;
		this.empty = pos;
	}
}
