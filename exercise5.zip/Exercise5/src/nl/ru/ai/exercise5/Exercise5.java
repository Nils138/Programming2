package nl.ru.ai.exercise5;

import static nl.ru.ai.exercise5.Maze.*;
import static nl.ru.ai.exercise5.Puzzle.*;

import java.util.ArrayList;

public class Exercise5 {
	static final int height = 3;
	static final int width = 3;

	public static void main(String[] arguments) {
		ArrayList<Candidate> candidates = new ArrayList<Candidate>();
		candidates.add(new Candidate(new Attempt(1, 7), -1)); // used to be a 0 here to indicate the parent which
																// worked, but this is what franc said in the lecture
		boolean found = false;
		int c = 0;
		while (c < candidates.size() && !found) {
			int row = candidates.get(c).attempt.row;
			int col = candidates.get(c).attempt.col;
			if (hasRabbit(row, col))
				found = true;
			visit(row, col);
			expandNodes(candidates, row, col, c);
			c++;
		}
		if (found) {
			showSolution(candidates);
		} else {
			System.out.println("No path found");
		}

		// -----------------------------------------------------------------------------------------

		int[][] board = { { 1, 2, 3 }, { 4, 5, 6 }, { 0, 7, 8 } };
		Puzzle begin = new Puzzle(board, new Pos(2, 0)); // don't forget to check this one when changing puzzles
		solve(begin); // this script actually doesn't need a "Pos" class since the empty space is
						// indicated by a '0', it might be possible to do it without but I think this is
						// good enough and probably a lot nicer.
	}

	/**
	 * checks all surrounding nodes/expands on current node
	 * 
	 * @param candidates
	 * @param row
	 * @param col
	 * @param c
	 */

	public static void expandNodes(ArrayList<Candidate> candidates, int row, int col, int c) {
		assert candidates != null : "arraylist should be initialized";
		checkNode(candidates, row + 1, col, c);
		checkNode(candidates, row - 1, col, c);
		checkNode(candidates, row, col + 1, c);
		checkNode(candidates, row, col - 1, c); // why is there no nice way of doing this :(
	}

	/**
	 * adds valid nodes (not a wall and not already visited)
	 * 
	 * @param candidates
	 * @param row
	 * @param col
	 * @param c
	 */

	public static void checkNode(ArrayList<Candidate> candidates, int row, int col, int c) {
		assert 0 <= row && row <= 9 : "row out of bounds";
		assert 0 <= col && col <= 8 : "col out of bounds";
		assert candidates != null : "arraylist should be initialized";
		assert c >= 0 : "c should be positive";
		if (!hasWall(row, col) && !hasVisited(row, col)) {
			candidates.add(new Candidate(new Attempt(row, col), c));
		}
	}

	/**
	 * prints the found path based on parent nodes
	 * 
	 * @param candidates
	 */

	public static void showSolution(ArrayList<Candidate> candidates) {
		assert candidates != null : "arraylist should be initialized";
		int c = candidates.size() - 1;
		ArrayList<Integer> solution = new ArrayList<Integer>();
		solution.add(c);
		while (c > 0) { // because if you check the parent of each node then you get a backwards path
						// (which I assume is to be avoided)
			c = candidates.get(c).parentCandidate;
			solution.add(c); // if you change this to a System.out.println then you get the backwards path
								// again.
		}
		System.out.println("Found path: ");
		for (int i = solution.size() - 1; i >= 0; i--) {
			System.out.println("(" + candidates.get(solution.get(i)).attempt.row + ", "
					+ candidates.get(solution.get(i)).attempt.col + ")");
		}
	}

	// -------------------------------------------------------------------------------------------

	/**
	 * solves a slide puzzle
	 * 
	 * @param begin
	 */

	public static void solve(Puzzle begin) {
		assert begin != null : "Puzzle should be initialized";
		ArrayList<Candidate> candidates = new ArrayList<Candidate>();
		int c = 0;
		boolean found = false;
		candidates.add(new Candidate(begin, -1)); // So I checked it and it doesn't matter whether this first parent is
													// a 0 or -1 :/
		while (c < candidates.size() && !found) {
			Puzzle p = candidates.get(c).puzzle;
			if (solved(p)) {
				found = true;
			} else { // there used to be a remember(p) function which saved the puzzle to check
						// whether the upcoming ones were duplicates.
				expandNodes(candidates, p, c);
				c++;
			}
		}
		if (found)
			showSolution(candidates, c);
		else
			System.out.println("No solution found");
	}

	/**
	 * checks whether the puzzle is solved based on the sliding puzzle's rules
	 * 
	 * @param puzzle
	 * @return
	 */

	public static boolean solved(Puzzle puzzle) {
		assert (puzzle != null) : "Puzle should be initialized";
		int[] solution = new int[width * height]; // this used to be a template array which I filled with all numbers as
													// if it were solved, but I like this solution way better :)
		int c = 0;
		for (int i = 0; i < puzzle.board.length; i++) {
			for (int j = 0; j < puzzle.board[i].length; j++) {
				solution[c] = puzzle.board[i][j];
				c++;
			}
		}
		if (solution[0] != 1 && solution[solution.length - 1] != 0)
			return false;
		for (int i = 1; i < solution.length - 1; i++) {
			if (solution[i - 1] != solution[i] - 1)
				return false;
		}
		return true;
	}

	/**
	 * checks what moves are possible and adds all possible moves
	 * 
	 * @param candidates
	 * @param p
	 * @param c
	 */

	public static void expandNodes(ArrayList<Candidate> candidates, Puzzle p, int c) {
		assert p != null : "Puzzle should be initialized";
		if (p.empty.row > 0) { // so I guess the solution with checkNodes above wasn't that ugly after all
			add(candidates, p, c, new Pos(p.empty.row - 1, p.empty.col));
		}
		if (p.empty.row < height - 1) {
			add(candidates, p, c, new Pos(p.empty.row + 1, p.empty.col));
		}
		if (p.empty.col > 0) {
			add(candidates, p, c, new Pos(p.empty.row, p.empty.col - 1));
		}
		if (p.empty.col < width - 1) {
			add(candidates, p, c, new Pos(p.empty.row, p.empty.col + 1));
		}
	}

	/**
	 * makes a new puzzle, swaps the free spot to position next and if it's not a
	 * duplicate, add it to the list
	 * 
	 * @param candidates
	 * @param p
	 * @param c
	 * @param next
	 */

	public static void add(ArrayList<Candidate> candidates, Puzzle p, int c, Pos next) {
		assert next != null : "Position should be initialized";
		assert next.col >= 0 && next.col <= width - 1 && next.row >= 0
				&& next.row <= height - 1 : "position out of bounds";
		assert candidates != null : "List should be initialized";
		Puzzle q = makeTemp(p);
		swap(q, next);
		boolean duplicate = false;
		for (int i = 0; i < candidates.size(); i++) {
			if (duplicate(q, i, candidates))
				duplicate = true;
		}
		if (!duplicate)
			candidates.add(new Candidate(q, c));
	}

	/**
	 * makes a new puzzle which is equal to puzzle p but isn't the same
	 * 
	 * @param p
	 * @return
	 */

	public static Puzzle makeTemp(Puzzle p) {
		assert p != null : "Puzzle should be initialized";
		int[][] temp = new int[width][height]; // this is so ugly but it's the only way this'll work
		for (int i = 0; i < p.board.length; i++) {
			for (int j = 0; j < p.board[i].length; j++) {
				temp[i][j] = p.board[i][j];
			}
		}
		Pos tempPos = new Pos(0, 0); // that is: giving q the same values as p but when q is changed that p isn't
										// also changed
		tempPos.col = p.empty.col;
		tempPos.row = p.empty.row;
		return new Puzzle(temp, tempPos);
	}

	/**
	 * swaps the empty spot to position "next"
	 * 
	 * @param q
	 * @param next
	 */

	public static void swap(Puzzle q, Pos next) {
		assert q != null : "Puzzle should be initialized";
		assert next != null : "Position should be initialized";
		q.board[q.empty.row][q.empty.col] = q.board[next.row][next.col];
		q.board[next.row][next.col] = 0; // no temporary variable needed because you know the empty slot is indicated by
											// a '0'
		q.empty = next;
	}

	/**
	 * shows the found path by checking each state's parent
	 * 
	 * @param candidates
	 * @param c
	 */

	public static void showSolution(ArrayList<Candidate> candidates, int c) {
		assert candidates != null : "arraylist should be initialized";
		assert c < candidates.size() : "counter out of bounds";
		ArrayList<Integer> solution = new ArrayList<Integer>();
		solution.add(c);
		while (c > 0) {
			c = candidates.get(c).parentCandidate;
			solution.add(c);
		}
		System.out.println("Found path: ");
		for (int i = solution.size() - 1; i >= 0; i--) {
			System.out.println(" - - - - - - -"); // these are just for readability, only work with 3 x 3 though.
			for (int j = 0; j < width; j++) {
				for (int k = 0; k < height; k++) {
					System.out.print(" | " + candidates.get(solution.get(i)).puzzle.board[j][k]);
				}
				System.out.println(" |"); // because with 4 x 4 you get two-digit numbers which screws up the lay-out
				System.out.println(" - - - - - - -");
			}
			System.out.println("");
		}
	}
}
