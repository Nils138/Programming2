package nl.ru.ai.exercise0;

public class Length
{
  public int minutes; // minutes (0..)
  public int seconds; // seconds (0..59)
  
}