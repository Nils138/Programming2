package nl.ru.ai.exercise0;

public class Track
{
  public String artist;
  public String cd;
  public int year;
  public int track;
  public String title;
  public String tags;
  public Length time;
  public String country;
}
