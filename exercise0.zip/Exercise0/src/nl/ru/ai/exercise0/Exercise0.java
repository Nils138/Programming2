package nl.ru.ai.exercise0;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Exercise0 {
	/**
	 * Program main entry point
	 * 
	 * @param args
	 *            arguments to the program (ignored)
	 */
	public static void main(String[] args) {
		assert true;
		part1();
		Track [] database=new Track[5000];
		int nr = 0;
		try {
			nr = readDatabase(database);
		} catch (FileNotFoundException e) {
			System.out.println("File not Found");
			e.printStackTrace();
		}
		System.out.println(nr+" tracks read");
		part2(database, nr);
	}
	
	/**
	 * adds the two times 12:34 and 23:45 and prints the result
	 */

	static void part1() {
		assert true;
		Length length1=fromString("12:34");
		Length length2=fromString("23:45");
		Length sum=add(length1,length2);
		System.out.println(toString(sum));
	}
	
	/**
	 * searches for the given track and if found, displays information about it.
	 * @param database
	 * @param search
	 * @param nr
	 */
	
	static void track(Track[] database, String search, int nr) {
		assert (database != null):"database doesn't exist";
		assert (nr != 0):"database is empty";
		int counter = 0;
		boolean found = false;
		for (int i = 0; i < nr;i++) {
			if (database[i].title.toLowerCase().contains(search.toLowerCase())) {
				System.out.println("Artist: " + database[i].artist);
				System.out.println("CD: " + database[i].cd);
				System.out.println("Year: " + database[i].year);
				System.out.println("Track: " + database[i].track);
				System.out.println("Title: " + database[i].title);
				System.out.println("Tags: " + database[i].tags);
				System.out.println("Time: " + toString(database[i].time));
				System.out.println("Country : " + database[i].country);
				counter++;
				found = true;
			}
		}
		if (found)
			System.out.println("Amount of songs with this name: " + counter);
		else
			System.out.println("Track not found");
	}
	
	/**
	 * searches the database for the artist, displays the artist
	 * @param database
	 * @param search
	 * @param nr
	 */
	
	static void artist(Track[] database, String search, int nr) {
		assert (database!= null):"array doesn't exist";
		assert (nr != 0):"array is empty";
		String artist = "";
		int counter = 0;
		boolean found = false;
		for (int i = 0; i < nr;i++) {
			if (database[i].artist.toLowerCase().contains(search.toLowerCase()) && !artist.equalsIgnoreCase(database[i].artist)) {
				artist = database[i].artist;
				System.out.println("Artist: " + database[i].artist);
				counter++;
				found = true;
			}
		}
		if (found)
			System.out.println("Amount of artists whose name contains  " + counter);
		else
			System.out.println("Artist not found");
	}
	
	/**
	 * searches the database for a given cd name, then displays information about the found cds 
	 * @param database
	 * @param search
	 * @param nr
	 */
	
	static void cds(Track[] database, String search, int nr) {
		assert (database != null):"array doesn't exist";
		assert (nr != 0):"array is empty";
		String cd = "";
		int counter = 0;
		boolean found = false;
		for (int i = 0; i < nr;i++) {
			if (database[i].artist.toLowerCase().contains(search.toLowerCase()) && !cd.equals(database[i].cd)) {
				cd = database[i].cd;
				System.out.println("Artist: " + database[i].artist);
				System.out.println("CD: " + database[i].cd);
				System.out.println("Year: " + database[i].year);
				counter++;
				found = true;
			}
		}
		if (found)
			System.out.println("Number of matches: " + counter);
		else
			System.out.println("CD not found");
	}
	
	/**
	 * fills an array with Track classes
	 * @param cdCounter
	 */
	
	static void fillArray(Track[] cdCounter) {
		assert (cdCounter != null):"array doesn't exist";
		for (int k = 0; k < cdCounter.length;k++) {
			cdCounter[k] = new Track();
		}
	}
	
	/**
	 * loops through all entries in the database and stores unique ones in a separate array
	 * @param cdCounter
	 * @param database
	 * @param counter
	 * @param nr
	 * @return counter
	 */
	
	static int checkCD(Track[] cdCounter, Track[] database, int counter, int nr) {
		assert (cdCounter != null && database != null):"arrays don't exist";
		assert (counter == 0):"counter is not 0";
		assert (nr != 0):"array is empty";
		for (int i = 0; i < nr; i ++) {
			boolean unique = true;
			for (int j = 0; j < cdCounter.length; j++) {
				if (cdCounter[j].cd != null  && cdCounter[j].cd.toLowerCase().contains(database[i].cd.toLowerCase()) && cdCounter[j].artist.toLowerCase().contains(database[i].artist.toLowerCase()))
					unique = false;
			}
			if (unique) {
				cdCounter[counter].cd = database[i].cd;
				cdCounter[counter].artist = database[i].artist;
				counter++;
			}
		}
		return counter;
	}
	
	/**
	 * displays the total amount of unique cds which can have the same name but be produced by a different artist
	 * @param database
	 * @param nr
	 */
	
	static void nrcds(Track[] database, int nr){
		assert (database != null):"array doesn't exist";
		assert (nr != 0):"array is empty";
		Track[] cdCounter = new Track[500];
		fillArray(cdCounter);
		int counter = 0;
		counter = checkCD(cdCounter, database, counter, nr);
		System.out.println("There are " + counter + " songs in this database");
	}
	
	/**
	 * displays the total amount of time needed to play each song once
	 * @param database
	 * @param nr
	 */
	
	static void time(Track[] database, int nr) {
		assert (database != null):"array doesn't exist";
		assert (nr != 0):"array is empty";
		Length totalTime = new Length();
		for (int i = 0; i < nr;i++) {
			totalTime = add(totalTime, database[i].time);
		}
		System.out.println(toString(totalTime));
	}
	
	/**
	 * displays the cd which has a track which matches the specified track name
	 * @param database
	 * @param search
	 * @param nr
	 */
	
	static void cdTrack(Track[] database, String search, int nr) {
		assert (database != null):"database doesn't exist";
		assert (nr != 0):"database is empty";
		String cd = "";
		int counter = 0;
		boolean found = false;
		for (int i = 0; i < nr;i++) {
			if (database[i].title.toLowerCase().contains(search.toLowerCase()) && !cd.toLowerCase().contains(database[i].cd.toLowerCase())) {
				cd = database[i].cd;
				System.out.println("Artist: " + database[i].artist);
				System.out.println("CD: " + database[i].cd);
				System.out.println("Year: " + database[i].year);
				counter++;
				found = true;
			}
		}
		if (found)
			System.out.println("Amount of cds with a track which has this name: " + counter);
		else
			System.out.println("Track not found");
	}
	
	/**
	 * checks if the specified search query matches one of the tags of each track and displays information about that track
	 * @param database
	 * @param search
	 * @param nr
	 */
	
	static void tag(Track[] database, String search, int nr) {
		assert (database != null):"database doesn't exist";
		assert (nr != 0):"database is empty";
		int counter = 0;
		boolean found = false;
		for (int i = 0; i < nr;i++) {
			String[] tags = database[i].tags.split(",");
			for (int j = 0; j < tags.length;j++) {
				if (tags[j].toLowerCase().contains(search.toLowerCase())) {
					System.out.println("Artist: " + database[i].artist);
					System.out.println("CD: " + database[i].cd);
					System.out.println("Year: " + database[i].year);
					System.out.println("Track: " + database[i].track);
					System.out.println("Title: " + database[i].title);
					System.out.println("Tags: " + database[i].tags);
					System.out.println("Time: " + toString(database[i].time));
					counter++;
					found = true;
				}
			}
		}
		if (found)
			System.out.println("Amount of songs with this tag: " + counter);
		else
			System.out.println("No track found which has this tag");
	}
	
	/**
	 * displays the artists of the given album and displays the number of matches
	 * @param database
	 * @param search
	 * @param nr
	 */
	
	static void artistCD(Track[] database, String search, int nr) {
		assert (database != null):"array doesn't exist";
		assert (nr != 0):"array is empty";
		String cd = "";
		int counter = 0;
		boolean found = false;
		for (int i = 0; i < nr;i++) {
			if (database[i].cd.toLowerCase().contains(search.toLowerCase()) && !cd.equals(database[i].cd)) {
				cd = database[i].cd;
				System.out.println("Artist: " + database[i].artist);
				System.out.println("CD: " + database[i].cd);
				counter++;
				found = true;
			}
		}
		if (found)
			System.out.println("Number of matches: " + counter);
		else
			System.out.println("CD not found");
	}
	
	/**
	 * displays all tracks on requested cd
	 * @param database
	 * @param search
	 * @param nr
	 */
	
	static void tracks(Track[] database, String search, int nr) {
		assert (database != null):"array doesn't exist";
		assert (nr != 0):"array is empty";
		String cd = "";
		int counter = 0;
		boolean found = false;
		for (int i = 0; i < nr;i++) {
			if (database[i].cd.equalsIgnoreCase(search)) {
				if (!cd.toLowerCase().contains(database[i].cd.toLowerCase())) {
					cd = database[i].cd;
					System.out.println("Artist: " + database[i].artist);
					System.out.println("CD: " + database[i].cd);
					System.out.println("Year: " + database[i].year);
					System.out.println("Track: " + database[i].track);
					System.out.println("Title: " + database[i].title);
					System.out.println("Tags: " + database[i].tags);
					System.out.println("Time: " + toString(database[i].time));
					System.out.println("Country : " + database[i].country);
					counter++;
					found = true;
				}else {
					System.out.println("Track: " + database[i].track);
					System.out.println("Title: " + database[i].title);
					System.out.println("Tags: " + database[i].tags);
					System.out.println("Time: " + toString(database[i].time));
					System.out.println("Country : " + database[i].country);
				}
			}
		}
		if (found)
			System.out.println(counter);
		else
			System.out.println("CD not found");	
	}
	
	/**
	 * Establishes the different kinds of actions to take with each command the user enters
	 * @param input
	 * @param database
	 * @param search
	 * @param nr
	 */
	
	static void chooseOutput(String command, Track[] database, String search, int nr) {
		assert (database != null && search != null):"parameter doesn't exist";
		switch (command) {
			case "track":
				track(database, search, nr);
			break;
			case "artist":
				artist(database, search, nr);
			break;
			case "cds":
				cds(database, search, nr);
			break;
			case "#cds":
				nrcds(database, nr);
			break;
			case "time":
				time(database, nr);
			break;
			case "cd?":
				cdTrack(database, search, nr);
			break;
			case "tag":
				tag(database, search, nr);
			break;
			case "artist?":
				artistCD(database, search, nr);
			break;
			case "tracks":
				tracks(database, search, nr);
			break;
			default:
				System.out.println("Invalid command");
			break;
		}
	}
	
	/**
	 * Gives the user the option to enter different commands
	 * @param database
	 * @param nr
	 */
	
	static void part2(Track[] database, int nr) {
		assert (database != null):"array doesn't exist";
		Scanner scanner = new Scanner(System.in);
		boolean done = false;
		while (!done) {
			System.out.println("Enter a command to filter songs:");
			String command = scanner.next();
			String search = scanner.nextLine();
			if (command.equals("stop")) {
				done = true;
				System.out.println("Program successfully stopped");
			}
			else
				chooseOutput(command, database, search, nr);
		}
		scanner.close();
	}

	/**
	 * calculate the sum of the specified times
	 * @param a
	 * @param b
	 * @return sum
	 */
	static Length add(Length a, Length b) {
		assert (a != null && b != null):"classes not defined";
		assert (a.seconds >= 0 && a.seconds <= 59 && b.seconds >= 0 && b.seconds <=59):"seconds out of bounds";
		assert (a.minutes >= 0 && b.minutes >= 0):"negative minutes";
		Length sum = new Length();
		if (a.seconds + b.seconds >= 60) {
			a.minutes++;
			sum.seconds = a.seconds + b.seconds - 60;
		}else 
			sum.seconds = a.seconds + b.seconds;
		sum.minutes = a.minutes + b.minutes;
		return sum;
	}

	/**
	 * Converts the given string in the format m..m:ss to a Length object
	 * @param string
	 * @return corresponding length object
	 */
	static Length fromString(String string) {
		assert (string.matches("[0-9]+:[0-9][0-9]")): "invalid input";
		Length songLength = new Length();
		String[] time = string.split(":");
		String minutes = time[0];
		String seconds = time[1];
		songLength.minutes = Integer.parseInt(minutes);
		songLength.seconds = Integer.parseInt(seconds);
		return songLength;
	}

	/**
	 * Converts a given length object into a string in the format m..m:ss
	 * @param length
	 * @return string representation
	 */
	static String toString(Length length) {
		assert (length != null):"class undefined";
		assert (length.seconds >= 0 && length.seconds <= 59 && length.minutes >= 0):"time out of bounds";
		if (length.seconds < 10) {
			return String.valueOf(length.minutes) + ":0" + String.valueOf(length.seconds);
		}
		return String.valueOf(length.minutes) + ":" + String.valueOf(length.seconds);
	}
	
	/**
	 * Reads the cd database from the file 'songs.txt' into the specified Track array
	 * @param database
	 * @return number of tracks read
	 * @throws FileNotFoundException 
	 */
	static int readDatabase(Track[] database) throws FileNotFoundException {
		assert (database != null):"array doesn't exist";
		Scanner scanner = new Scanner (new FileInputStream("songs.txt"));
		int counter = 0;
		while (scanner.hasNext()) {
			database[counter] = new Track();
			database[counter].artist = scanner.nextLine();
			database[counter].cd = scanner.nextLine();
			database[counter].year = scanner.nextInt();
			scanner.nextLine();
			database[counter].track = scanner.nextInt();
			scanner.nextLine();
			database[counter].title = scanner.nextLine();
			database[counter].tags = scanner.nextLine();
			database[counter].time = fromString(scanner.nextLine());
			database[counter].country = scanner.nextLine();
			counter++;
		}
		scanner.close();
		return counter;
	}
}