package nl.ru.ai.exercise4;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

public class Exercise4 {
	/*
	 * Exercise 1b 
	 * Number of fails in the first test case: 0 
	 * Number of fails in the second test case: 8 
	 * Number of fails in the third test case: 114 
	 * Number of fails in the fourth test case: 30 
	 * In the first test case there's only one option so it can't fail. 
	 * In the second test case the length of the array is
	 * not 0 so it still has to try all possible combinations, even though the
	 * target is lower than the lowest number in the array. 
	 * In the third test case
	 * there are a lot more possibilities because it has to test with every number
	 * in the array, while in the second test case it saw with each number that it
	 * was already higher than the target. 
	 * In the fourth test case there are values
	 * in the array which are lower than the target, so it has to try some
	 * combinations. But with all combinations of these values you can never reach
	 * the target so it's in between case 2 and 3.
	 * 
	 * Exercise 1d 
	 * Number of fails in the first test case: 0 
	 * Number of fails in the second test case: 0 
	 * Number of fails in the third test case: 2
	 * Number of fails in the fourth test case: 0 
	 * Number of prunes in the first test case: 0 
	 * Number of prunes in the second test case: 1 
	 * Number of prunes in the third test case: 3 
	 * Number of prunes in the fourth test case: 14 
	 * As we can see, most of the fails are taken care of by the pruning.
	 * The only case where there are still fails are test case 3, which is the 
	 * one where there are the most solutions and the most options for solutions.
	 * The fourth test case now has the most pruning, because it's always likely a 
	 * solution is possible based on the values of the remaining numbers, even though
	 * there isn't any real solution. The reason why it prunes so much more in the fourth 
	 * case is because in the third case it's more often that there's a solution than that 
	 * there's no solution possible.
	 * 
	 * Exercise2
	 * Just a small comment: I feel like the only reason why this is difficult is because 
	 * you have to use recursion: I feel like this could've been done way easier just using 
	 * a simple loop of some kind.
	 * 
	 * Exercise3
	 * I hope it wasn't mandatory to make the solve() function a void, because I felt it was way easier
	 * to make it a boolean: this way it can break whenever I want, instead of completing the entire
	 * function even though it's already been solved.
	 */
	static int nrOfFails = 0;
	static int nrOfPrunes = 0;
	static final int dim = 9;

	public static void main(String[] args) {
		ArrayList<Integer> solutions0 = new ArrayList<Integer>();
		int[] money0 = {};
		int target0 = 0;
		System.out.println("Amount of solutions: " + solutions(money0, 0, target0, solutions0));
		System.out.println("Number of fails: " + nrOfFails);
		nrOfFails = 0;
		System.out.println("Number of prunes: " + nrOfPrunes);
		nrOfPrunes = 0;

		ArrayList<Integer> solutions1 = new ArrayList<Integer>();
		int[] money1 = { 2, 2, 2, 5, 10, 10, 20 };
		int target1 = 1;
		System.out.println("Amount of solutions: " + solutions(money1, 0, target1, solutions1));
		System.out.println("Number of fails: " + nrOfFails);
		nrOfFails = 0;
		System.out.println("Number of prunes: " + nrOfPrunes);
		nrOfPrunes = 0;

		ArrayList<Integer> solutions2 = new ArrayList<Integer>();
		int[] money2 = { 20, 10, 10, 5, 2, 2, 2 };
		int target2 = 42;
		System.out.println("Amount of solutions: " + solutions(money2, 0, target2, solutions2));
		System.out.println("Number of fails: " + nrOfFails);
		nrOfFails = 0;
		System.out.println("Number of prunes: " + nrOfPrunes);
		nrOfPrunes = 0;

		ArrayList<Integer> solutions3 = new ArrayList<Integer>();
		int[] money3 = { 20, 50, 1000, 1000, 2000 };
		int target3 = 2021;
		System.out.println("Amount of solutions: " + solutions(money3, 0, target3, solutions3));
		System.out.println("Number of fails: " + nrOfFails);
		nrOfFails = 0;
		System.out.println("Number of prunes: " + nrOfPrunes);
		nrOfPrunes = 0;
		
		//Lift problem: displays the highest 6 numbers while they're lower than 500
		
		int[] solutions = new int[6];
		int[] persons = {10, 30, 40, 41, 80, 90, 50, 55, 92, 66, 82, 62, 70};
		int sum = 0;
		System.out.println("The amount of solutions is: " + liftSolutions(persons, 0, solutions, sum));

		//Sudoku: solves the sudoku displayed in sudoku.txt
		
		int[] puzzle = new int[dim*dim];
		readFromFile(puzzle, "sudoku.txt");
		if (solve(puzzle))
			dump(puzzle);
		else
			System.out.println("No solutions were found");
	}
	
	/**
	 * Reads a file with 9 rows and 9 columns.
	 * Note: this only reads the first 81 numbers or spaces in the file and disregards the rest
	 * It doesn't check whether the file is indeed 81 characters long or if it contains other characters.
	 * This isn't a problem for us because a sudoku may be submitted with a title of some kind which is now ignored.
	 * If you think it's nicer to make us check whether the file is just a grid of 9 x 9 with just numbers and spaces, just tell us.
	 * @param puzzle
	 * @param fileName
	 */
	
	static void readFromFile(int[] puzzle, String fileName) {
		assert (puzzle != null) : "source doesn't exist";
		try {
			Reader reader = new FileReader(fileName);
			for (int i = 0; i < dim*dim; i++) {
				int c = reader.read();
				if (c >= 49 && c <= 57)
					puzzle[i] = (char)c - '0'; //just a way to transform int into char into int value (49 to '1' to 1)
				else if (c == 32) {
					puzzle[i] = 0; //spaces indicate a free square: indicated as a 0 in the array
				}else {
					i--; //for whitespaces and the like
				}
			}
			reader.close();
		} catch (IOException e) {
			System.out.println("File cannot be found");
			e.printStackTrace();
		}
	}
	
	/**
	 * Solves the sudoku specified in the specified array
	 * @param puzzle
	 * @return true if there's a solution, false if there isn't
	 */
	
	static boolean solve(int[] puzzle){
		assert puzzle != null: "array should be initialized";
		int free = findFirstFreePosition(puzzle);
		if (free == 8)
			System.out.println("yay");
		if (free != puzzle.length){
			for (int i = 1; i <= dim; i++){
				puzzle[free] = i;
				if (isValid(puzzle, free) && solve(puzzle))
					return true;
				else {
					puzzle[free] = 0;
				}
			}
			return false;
		}
		return true;
	}
	
	/**
	 * runs through the array to find the first place where a 0 occurs: this is the first free spot where
	 * the solving can begin; returns puzzle.length if there aren't any 0's left and the puzzle is solved.
	 * @param puzzle
	 * @return
	 */

	static int findFirstFreePosition(int[] puzzle){
		assert puzzle != null: "array should be initialized";
		for (int i = 0; i < puzzle.length; i++){
			if (puzzle[i] == 0)
				return i;
		}
		return puzzle.length;
	}
	
	/**
	 * Checks whether the latest move was valid
	 * @param puzzle
	 * @param free
	 * @return true if the entered value was valid, false if otherwise
	 */

	static boolean isValid(int[] puzzle, int free){
		assert puzzle != null: "array should be initialized";
		assert free >= 0 && free < puzzle.length:"free spot out of bounds";
		int col = free%dim;
		int row = free/dim;
		for (int i = 9 * row; i < 9 * row + 9; i++){
			if (puzzle[i] == puzzle[free] && i != free)
				return false;
		}
		for (int i = col; i < dim*dim; i+= 9){
			if (puzzle[i] == puzzle[free] && i != free)
				return false;
		}
		return findBox(puzzle, free, row, col);
	}
	
	/**
	 * checks the box/block/region/grid whether any value is the same as the value "free"
	 * @param puzzle
	 * @param free
	 * @param row
	 * @param col
	 * @return true if there's no duplicate, false if otherwise
	 */
	
	static boolean findBox(int[] puzzle, int free, int row, int col) {
		assert puzzle != null: "array should be initialized";
		assert free >= 0 && free < puzzle.length:"free spot out of bounds";
		assert row >= 0 && row <= 8:"row out of bounds";
		assert col >= 0 && col <= 8:"column out of bounds";
		int topLeft = row / 3 * 27 + col / 3 * 3;
		for (int i = 0; i < 27; i+=9) {
			for (int j = 0; j < 3; j++) {
				if (puzzle[topLeft + i + j] == puzzle[free] && topLeft+i+j != free)
					return false;
			}
		}
		return true;
	}
	
	/**
	 * dumps the puzzle into a 9 x 9 grid
	 * @param puzzle
	 */
	
	static void dump(int[] puzzle){
		assert puzzle != null: "array should be initialized";
		for (int i = 0; i < 9; i++){
			for (int j = 0; j< 9; j++){
				System.out.print(puzzle[9*i + j]);
			}
			System.out.println("");
		}
	}
	
	/**
	 * recursively saves the highest 6 numbers from specified array into a new array, as long
	 * as the total doesn't exceed 500
	 * @param persons
	 * @param c
	 * @param solutions
	 * @param sum
	 * @return amount of solutions
	 */
	
	static int liftSolutions(int[] persons, int c, int[] solutions, int sum) {
		assert persons != null : "array should be initialized";
		assert solutions != null :"array should be initialized";
		assert c >= 0 && c <= persons.length;
		if (c == persons.length) {
			showSolutions(solutions);
			return 1;
		}
		if (sum > 500) {
			return 0;
		}
		solutions[lowestIndex(solutions)] = persons[c];
		sum = sum(solutions, 0);
		return liftSolutions(persons, c+1, solutions, sum); //per definition 1 or 0, unless duplicates
	}
	
	/**
	 * dumps an int array
	 * @param solutions
	 */
	
	static void showSolutions(int[] solutions) {
		assert solutions != null: "array should be initialized";
		for (int i = 0; i < solutions.length;i++) {
			System.out.println(solutions[i]);
		}
	}
	
	/**
	 * Searches for the lowest number in the given array and return its index
	 * @param solutions
	 * @return index
	 */

	static int lowestIndex (int[] solutions) {
		assert solutions != null: "array should be initialized";
		int lowest = solutions[0];
		int index = 0;
		for (int i = 0; i < solutions.length; i++) {
			if (solutions[i] < lowest) {
				lowest = solutions[i];
				index = i;
			}
		}
		return index;
	}
	
	/**
	 * Returns the number of ways of creating specified target value as a sum of
	 * money starting with c
	 * 
	 * @param money
	 * @param c
	 * @param target
	 * @param solutions
	 * @return number of ways
	 */
	private static int solutions(int[] money, int c, int target, ArrayList<Integer> solutions) {
		assert money != null : "array should be initialized";
		assert solutions != null :"array should be initialized";
		assert c >= 0 && c <= money.length;
		if (target == 0) {
			showSolutions(solutions);
			return 1;
		}
		if (target < 0 || c >= money.length) {
			nrOfFails++;
			return 0;
		}
		if (sum(money, c) < target || lowest(money, c) > target) {
			nrOfPrunes++;
			return 0;
		}
		solutions.add(money[c]);
		int with = solutions(money, c + 1, target - money[c], solutions);
		solutions.remove(solutions.size() - 1);
		int without = solutions(money, c + 1, target, solutions);
		return with + without;
	}
	
	/**
	 * calculates the sum of the elements from c to the end of the array in a specified array
	 * @param money
	 * @param c
	 * @return sum
	 */

	static int sum(int[] money, int c) {
		assert money != null: "array should be initialized";
		assert c >= 0 && c < money.length: "counter out of bounds";
		int sum = 0;
		for (int i = c; i < money.length; i++) {
			sum += money[i];
		}
		return sum;
	}
	
	/**
	 * searches the specified array from c to the end of the array for the lowest number
	 * @param money
	 * @param c
	 * @return lowest
	 */

	static int lowest(int[] money, int c) {
		assert money != null: "array should be initialized";
		assert c >= 0 && c < money.length: "counter out of bounds";
		if (money.length == 0)
			return 0;
		int lowest = money[c];
		for (int i = c; i < money.length; i++) {
			if (money[i] < lowest)
				lowest = money[i];
		}
		return lowest;
	}

	/**
	 * Dumps the given arraylist
	 * 
	 * @param solutions
	 */

	static void showSolutions(ArrayList<Integer> solutions) {
		assert solutions != null : "Array doesn't exist";
		System.out.println("Possible solutions are:");
		for (int i = 0; i < solutions.size(); i++) {
			System.out.println(solutions.get(i));
		}
	}
}
