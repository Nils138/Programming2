package nl.ru.ai.exercise1;

public class Track implements Comparable<Track> {
	public String artist; // name of artist
	public String cd; // cd title
	public int year; // year production
	public int track; // track number
	public String title; // track title
	public String tags; // track tags
	public Length time; // track length
	public String country; // artist country

	/**
	 * Compare this track with an other based on track length
	 * 
	 * @param other
	 * @return 1 if track is longer, else -1
	 */
	/*public int compareTo(Track other) {
		assert (other != null):"Track doesn't exist";
		Exercise1.counter++;
		return time.compareTo(other.time);
	}*/

	public int compareTo(Track other) {
		assert (other != null):"Track doesn't exist";
		Exercise1.counter++;
		if (artist.compareTo(other.artist) == 0) {
			if (cd.compareTo(other.cd) == 0 && year == other.year) {
				if (track < other.track)
					return -1;
				return 1;
			}
			return cd.compareTo(other.cd);
		}
		return artist.compareTo(other.artist);
	}
}
