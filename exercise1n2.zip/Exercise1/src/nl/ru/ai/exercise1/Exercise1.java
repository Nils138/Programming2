package nl.ru.ai.exercise1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

public class Exercise1 {
	private static final String DATABASE_FILENAME = "songs.txt";
	public static int counter;
	/*
	 * Exerise 3: Bubble sort uses compareTo 11377051 times, insertion sort 5585402
	 * times, and selection sort 11383606 times. All methods have O(n^2) so the
	 * order is the same (because they have two loops, so n * n). Bubble sort and
	 * selection sort are approximately the same but insertion is twice as small.
	 * This can be explained through the way insertion sort works. The first element
	 * in the insertion sort array doesn't have to be compared at all, the second
	 * will only have to be compared to the first, etc. So overall insertion sort
	 * won't have to compare every element twice (once with the sorted and once with
	 * the unsorted parts of the list).
	 * 
	 * For the compareTo from 2a: Bubble sort uses compareTo 11339946 times,
	 * insertion sort 11376166 times, and selection sort 11383606 times. We can see
	 * that bubble sort and selection sort stay roughly the same, but insertion sort
	 * loses its advantage over the other two. This is the case because you compare
	 * more elements if you sort based on artist, then cd, then track because you
	 * have to loop through all the previous tracks on the cd giving you a worse
	 * situation than before.
	 */

	/*
	 * Here we come, get out of the way, doesn't matter what the people say
	 */
	public static void main(String[] args) {
		try {
			ArrayList<Track> database = new ArrayList<Track>();
			/*
			 * Read database
			 */
			readDatabase(database);
			System.out.printf("%d songs read from datatabase '%s'\n", database.size(), DATABASE_FILENAME);
			/*
			 * Ask for sorting method
			 */
			Scanner input = new Scanner(System.in);
			SortingMethod method = askForSortingMethod(input);
			/*
			 * Sort
			 */
			counter = 0;
			System.out.printf("Sorting with %s\n", method);
			switch (method) {
			case BUBBLE_SORT:
				bubbleSort(database);
				break;
			case INSERTION_SORT:
				insertionSort(database);
				break;
			case SELECTION_SORT:
				selectionSort(database);
				break;
			case HEAP_SORT:
				heapSort(database);
			}
			System.out.println("Sorted!");
			/*
			 * Show result
			 */
			dumpDatabase(database);
			System.out.println(counter);
		} catch (FileNotFoundException exception) {
			System.out.printf("Error opening database file '%s': file not found\n", DATABASE_FILENAME);
		}
	}

	/**
	 * Displays the specified database (which is hopefully sorted)
	 * 
	 * @param database
	 */

	private static void dumpDatabase(ArrayList<Track> database) {
		assert (database != null) : "database doesn't exist";
		assert (database.size() != 0) : "database is empty";
		for (int i = 0; i < database.size(); i++) {
			System.out.printf("%-26s %-32s %4d %s\n", database.get(i).artist, database.get(i).cd, database.get(i).track,
					database.get(i).time);
		}
	}

	/**
	 * Ask the user for a sorting method, repeats until the input is valid
	 *
	 * @param input
	 *            scanner
	 * @return sorting method
	 */
	private static SortingMethod askForSortingMethod(Scanner input) {
		assert (input != null) : "Scanner doesn't exist";
		/*
		 * Show possible sorting methods
		 */
		for (SortingMethod method : SortingMethod.values())
			System.out.printf("%d : %s\n", method.ordinal(), method);
		/*
		 * Loop until valid choice
		 */
		SortingMethod choice = null;
		while (choice == null) {
			System.out.println("Enter choice: ");
			int selection = input.nextInt();
			if (selection >= 0 && selection < SortingMethod.values().length)
				choice = SortingMethod.values()[selection];
			else
				System.out.println("Invalid choice, try again!");
		}
		return choice;
	}

	/**
	 * Reads the cd database from the database filename into the specified track
	 * arraylist
	 * 
	 * @param database
	 *            this is the database that will be filled with the input.
	 * @return number of tracks read
	 * @throws FileNotFoundException
	 */
	static void readDatabase(ArrayList<Track> database) throws FileNotFoundException {
		assert (database != null) : "database doesn't exist";
		FileInputStream inputStream = new FileInputStream(DATABASE_FILENAME);
		Scanner scanner = new Scanner(inputStream);
		while (scanner.hasNext()) {
			Track track = new Track();
			track.artist = scanner.nextLine();
			track.cd = scanner.nextLine();
			track.year = scanner.nextInt();
			scanner.nextLine();
			track.track = scanner.nextInt();
			scanner.nextLine();
			track.title = scanner.nextLine();
			track.tags = scanner.nextLine();
			track.time = new Length(scanner.nextLine());
			track.country = scanner.nextLine();
			database.add(track);
		}
		scanner.close();
	}

	/*************** Auxiliary array routines from lecture ***************/
	/**
	 * Checks if the slice of the specified array is sorted
	 * 
	 * @param array
	 * @param slice
	 * @return true if the slice of the array is in ascending order, false otherwise
	 */
	static <T extends Comparable<T>> boolean isSorted(ArrayList<T> array, Slice slice) {
		assert array != null : "Array should be initialized";
		assert slice.isValid() : "Slice should be valid";
		for (int i = slice.from; i < slice.upto - 1; i++)
			if (array.get(i).compareTo(array.get(i + 1)) > 0)
				return false;
		return true;
	}

	/**
	 * Find position in array slice where to insert new element
	 * 
	 * @param array
	 * @param slice
	 * @param y
	 *            element for which the position should be returned
	 * @return position where to insert
	 */
	static <T extends Comparable<T>> int findInsertPosition(ArrayList<T> array, Slice slice, T y) {
		assert array != null : "Array should be initialized";
		assert slice.isValid() : "Slice should be valid";
		assert isSorted(array, slice);
		for (int i = slice.from; i < slice.upto; i++)
			if (array.get(i).compareTo(y) >= 0)
				return i;
		return slice.upto;
	}

	/**
	 * Swap two elements in an array
	 * 
	 * @param array
	 * @param i
	 * @param j
	 */
	private static <T extends Comparable<T>> void swap(ArrayList<T> array, int i, int j) {
		assert array != null : "Array should be initialized";
		assert i >= 0 && i < array.size() : "First index is invalid";
		assert j >= 0 && j < array.size() : "Second index is invalid";
		T help = array.get(i);
		array.set(i, array.get(j));
		array.set(j, help);
	}

	/*************** Array based Sorting routines from lecture ***************/
	/**
	 * Sorts an array in situ in ascending order using selection sort
	 * 
	 * @param array
	 */
	static <T extends Comparable<T>> void selectionSort(ArrayList<T> array) {
		assert array != null : "array should be initialized";
		for (int i = 0; i < array.size(); i++) {
			int j = indexOfSmallestValue(array, new Slice(i, array.size()));
			swap(array, i, j);
		}
	}

	/**
	 * Finds index of smallest value in array slice
	 * 
	 * @param array
	 * @param slice
	 * @return index of smallest value
	 */
	static <T extends Comparable<T>> int indexOfSmallestValue(ArrayList<T> array, Slice slice) {
		assert array != null : "Array should be initialized";
		assert slice.isValid() && slice.upto <= array.size() : "Slice should be valid";
		assert slice.upto - slice.from > 0 : "Slice should be non-empty";
		int index = slice.from;
		for (int i = slice.from + 1; i < slice.upto; i++)
			if (array.get(i).compareTo(array.get(index)) < 0)
				index = i;
		return index;
	}

	/**
	 * Sorts an array in situ in ascending order using bubble sort
	 * 
	 * @param array
	 */
	static <T extends Comparable<T>> void bubbleSort(ArrayList<T> array) {
		assert array != null : "array should be initialized";
		int length = array.size();
		while (!bubble(array, new Slice(0, length)))
			length--;
	}

	/**
	 * Swap all adjacent pairs in the array slice that are not in the right order
	 * 
	 * @param array
	 * @param slice
	 * @return array slice is sorted
	 */
	static <T extends Comparable<T>> boolean bubble(ArrayList<T> array, Slice slice) {
		assert array != null : "Array should be initialized";
		assert slice.isValid() && slice.upto <= array.size() : "Slice should be valid";
		boolean isSorted = true;
		for (int i = slice.from; i < slice.upto - 1; i++)
			if (array.get(i).compareTo(array.get(i + 1)) > 0) {
				swap(array, i, i + 1);
				isSorted = false;
			}
		return isSorted;
	}
	
	/**
	 * Changes specified list into a heap
	 * @param array
	 * @param unsorted
	 */

	static <T extends Comparable<T>> void buildHeap(ArrayList<T> array, int unsorted) {
		assert array != null :"Array should be initialized";
		assert unsorted < array.size():"Unsorted out of bounds";
		for (int j = 0; j < unsorted; j++) {
			if (array.get(j).compareTo(array.get((j - 1) / 2)) > 0) { //works when sorting backwards, am tempted to sort backwards then reverse entire array
				swap(array, j, (j - 1) / 2);
			}
		}
	}

	/**
	 * Sorts an array in situ in ascending order using insertion sort
	 * 
	 * @param array
	 */
	static <T extends Comparable<T>> void insertionSort(ArrayList<T> array) {
		assert array != null : "array should be initialized";
		for (int i = 0; i < array.size(); i++) {
			array.add(findInsertPosition(array, new Slice(0, i), array.get(i)), array.get(i));
			array.remove(i + 1);
		}
	}
	
	/**
	 * Sorts an array in situ in ascending order using insertion sort
	 * @param array
	 */

	static <T extends Comparable<T>> void heapSort(ArrayList<T> array) {
		assert array != null : "Array should be initialized";
		buildHeap(array, array.size());
		for (int i = 1; i < array.size(); i++) {
			swap(array, 0, array.size() - i);
			buildHeap(array, array.size() - i);
		}
	}
}