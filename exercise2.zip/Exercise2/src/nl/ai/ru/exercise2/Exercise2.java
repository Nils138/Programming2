package nl.ai.ru.exercise2;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;

/*
 * Part 1.2
 * The "removeDuplicates" function has only one loop, so its run complexity is O(n), with n being the size of the arraylist. 
 * But since another function is called inside removeDuplicates (addWithoutDuplicates), which also contains a loop based on this same arraylist,
 * the run complexity is O(n^2). All the other lines happen regardless of the size of the input so they have no effect on the run complexity.
 * 
 * 
 * Part 1.3
 * If the array is already sorted, then it's possible to just loop once, adding an element to the new array only if it's different than the previous one.
 * Since you only loop once with this strategy, its run complexity is just O(n). You change the while loop to just an if-statement which has a complexity
 * of 1 instead of n so you remove a loop and make the run complexity O(n).
 * 
 * Part 1.4
 * The function removeSortedDuplicates only has one loop. In that loop it doesn't call a function to search through an entire arrayList of characters
 * which you've already come across, rather it compares the new character to the last character that it came across. So the run complexity is O(n)
 * but it still removes all duplicates from a sorted arraylist. It doesn't work for any arraylist because it actually only removes characters which
 * are the same and are directly after each other, so it still removes all duplicates in a sorted arraylist. 
 * 
 * Part 2a.1
 * This code won't compile and give an error message "x cannot be resolved to a variable" but the run complexity would be O(sqrt(n)) because it loops
 * once from 2 upto sqrt(input).
 * 
 * Part 2a.2
 * O(1) because no matter the size of the input, this function only outputs one line.
 * 
 * Part 2a.3
 * O(n sqrt(n)) because there's only one loop, all the other lines/actions are executed regardless of the input size, but it calls the function
 * isPrime inside the loop, which has run complexity sqrt(n) so it's n * sqrt(n) 
 * 
 * Part 2a.4
 * Again O(n) because there's only one loop (even though it loops from 0 upto inputsize-1)
 * 
 * Part 2b. 1 phase 1:
 * 	            3                  28                  28
 *    	      /    \             /     \             /    \
 * 	         28     14   -->   3       14   -->    6      14
 *          /  \   /   \      /  \    /   \       / \    / \
 *         -5   6  12   3   -5    6  12    3     -5  3  12  3
 *        
 *        phase 2:
 *         28, 6, 14, 3, 6, 12, 3 --> 3, 6, 14, 3, 6, 12, 28 --> 14, 3, 12, -5, 3, 6, 28 --> 12, 3, 6, -5, 3, 14, 28 --> 3, 3, 6, -5, 12, 14, 28
 *         --> 6, 3, 3, -5, 12, 14, 28 --> -5, 3, 3, 6, 12, 14, 28  
 * Part 2b.2
 *    The looping to build a heap takes run complexity 2log(n), because with each element you build up a list of sorted elements which you don't heap again
 *    But for each element you have to loop through the whole list to make sure it's the highest one so it's actually n * 2log(n). 
 *    Since the swapping is not dependent on input size, that doesn't affect the run complexity so the total run complexity of heap sort is n * 2log(n).
 */

public class Exercise2 {
	public static void main(String[] arguments) throws IOException {
		ArrayList<Character> source = new ArrayList<Character>();
		ArrayList<Character> destination = new ArrayList<Character>();
		readFromFile(source, "aliceSorted.txt");
		removeSortedDuplicates(source, destination);
		System.out.printf("Source: %s\n", source);
		System.out.printf("Destination: %s\n", destination);
		ArrayList<Integer> test = new ArrayList<Integer>();
		test.addAll(Arrays.asList(3, 28, 14, -5, 6, 12, 3));
		pickHeap(test);
		System.out.printf("Heap: %s \n", test);
	}

	/**
	 * Sorts in situ with heapsort
	 * @param array
	 */

	private static void pickHeap(ArrayList<Integer> array) {
		assert array != null:"Array should be initialized";
		buildHeap(array, array.size());
		for (int i = 1; i < array.size(); i++) {
			swap(array, 0, array.size() - i);
			buildHeap(array, array.size() - i);
		}
	}
	
	/**
	 * Builds a heap out of an array
	 * @param array
	 * @param unsorted
	 */

	private static void buildHeap(ArrayList<Integer> array, int unsorted) {
		assert unsorted < array.size():"Unsorted out of bounds";
		assert array != null: "Array should be initialized";
		for (int j = 0; j < unsorted; j++) {
			pushUp(array, j);
		}
	}

	/**
	 * swaps parent with child if child is bigger than parent
	 * @param array
	 * @param j
	 */
	
	private static void pushUp(ArrayList<Integer> array, int j) {
		assert array != null:"Array should be initialized";
		assert j < array.size():"index out of bounds";
		if (array.get(j) > array.get((j - 1) / 2)) {
			swap(array, j, (j - 1) / 2);
		}
	}
	
	/**
	 * Swaps two elements in an integer arraylist
	 * @param array
	 * @param i
	 * @param j
	 */

	private static void swap(ArrayList<Integer> array, int i, int j) {
		assert array != null : "Array should be initialized";
		assert i >= 0 && i < array.size() : "First index is invalid";
		assert j >= 0 && j < array.size() : "Second index is invalid";
		int help = array.get(i);
		array.set(i, array.get(j));
		array.set(j, help);
	}

	/**
	 * Copies sorted characters from source array to destination array, without
	 * duplicates
	 * 
	 * @param source
	 * @param destination
	 */

	private static void removeSortedDuplicates(ArrayList<Character> source, ArrayList<Character> destination) {
		assert source != null : "Source array should be initialized";
		assert destination != null : "Destination array should be initialized";
		char character = 'z';
		for (int i = 0; i < source.size(); i++) {
			if (!source.get(i).equals(character)) {
				destination.add(source.get(i));
			}
			character = source.get(i);
		}
	}

	/**
	 * reads the characters from a given file and puts them in a specified array
	 * 
	 * @param source
	 * @param fileName
	 */

	private static void readFromFile(ArrayList<Character> source, String fileName) {
		assert (source != null) : "source doesn't exist";
		try {
			Reader reader = new FileReader(fileName);
			int c;
			while ((c= reader.read()) > 0) {
				if (!Character.isWhitespace((char)c)) {
					source.add((char)c);
				}
			}
			reader.close();
		} catch (IOException e) {
			System.out.println("File cannot be found");
			e.printStackTrace();
		}
		
	}
}