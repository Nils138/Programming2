package nl.ru.ai.exercise3;

import java.util.ArrayList;

public class Exercise3 {
	public static int temp1;
	public static int temp2;

	/*
	 * Exercise 2a The time it takes to compute the next fibonacci number takes
	 * twice as long as the previous, and fibonacci number 47 is negative. The first
	 * one can be explained through the fact that it needs to calculate all the
	 * previous fibonacci numbers as well. The second one can be explained by an
	 * integer overflow(?) where the number is larger than the system can handle so
	 * the first binary character becomes a 1 which makes it negative. This occurs
	 * not only with 47 but also 49, 50, and 51, and possibly more but this is where
	 * my laptop almost crashed so I can't check more than these. But I assume this
	 * keeps going until 1000, if the program even gets there and doesn't give a
	 * stackoverflow error or something.
	 * 
	 * Exercise 2b. Correction in exercise 2a.: the negative don't continue up until
	 * 1000, they alter between positive and negative. I still stand by the
	 * conclusion that this has to do with the numbers being too big for eclipse to
	 * handle so it becomes negative.
	 */

	public static void main(String[] args) {
		System.out.println(sum(100));
		System.out.println(power(2, 8));
		int[] array = { 12, 8, 14, 23, 16 };
		System.out.println(minimum(array, array.length));
		System.out.println(gcd(1650, 2250));
		/*
		 * Create an ArrayList of names
		 */
		ArrayList<String> names = new ArrayList<String>();
		/*
		 * Question: wouldn't it be nicer to make an array with these names and then use
		 * names.addAll(Arrays.asList("Ellen", "Marit", ...));?
		 */
		names.add("Ellen");
		names.add("Marit");
		names.add("Lea");
		names.add("Max");
		names.add("Leander");
		names.add("Pleun"); // corrected wrong name
		names.add("Elena");
		names.add("Franc"); // corrected wrong name.
		names.add("Bart");
		names.add("Kim");
		names.add("Anna");
		names.add("Gijs");
		/*
		 * Print them (unsorted)
		 */
		System.out.println("Unsorted: " + names);
		/*
		 * Sort them
		 */
		selectionSort(names, 0);
		/*
		 * Print them (sorted)
		 */
		System.out.println("Sorted: " + names);
		/*
		 * print fibonacci with recursion
		 */
		// for (int i = 0; i < 1000; i++) { System.out.println(fib(i)); }
		/*
		 * print fibonacci with recursion with reasonable execution time
		 */
		int[] fib = new int[1000];
		for (int i = 0; i < 1000; i++) {
			System.out.println(effFib(i, fib));
		}
		/*
		 * print fibonacci with recursion with reasonable execution time with lowest
		 * complexities
		 */
		int[] fib2 = new int[3];
		for (int i = 0; i < 1000; i++) {
			System.out.println(fastFib(i, fib2, 0));
		}
	}

	/**
	 * returns the sum of all numbers up to n
	 * 
	 * @param n
	 * @return sum of all numbers up to n
	 */

	static int sum(int n) {
		assert n >= 0 : "number is negative";
		if (n == 0) {
			return 0;
		} else {
			return n + sum(n - 1);
		}
	}

	/**
	 * calculates x to the power n
	 * 
	 * @param x
	 * @param n
	 * @return x^n
	 */

	static double power(double x, double n) {
		assert n >= 0 : "number is negative";
		if (n == 0) {
			return 1;
		} else {
			return x * power(x, n - 1);
		}
	}

	/**
	 * calculates the minimum value of an array element 0 to n
	 * 
	 * @param a
	 * @param n
	 * @return the minimum value in the specified array
	 */

	static int minimum(int[] a, int n) {
		assert n > 0 : "number is negative";
		assert a != null : "array should be initialized";
		assert n < a.length : "number out of bounds";
		if (n == 1)
			return a[0];
		else
			return Math.min(a[n - 1], minimum(a, n - 1));
	}

	/**
	 * calculates the greatest common divider of the two given ints
	 * 
	 * @param n
	 * @param m
	 * @return the greatest common divider of the two specified ints
	 */

	static int gcd(int n, int m) {
		assert n >= 0 : "number n is negative";
		assert m >= 0 : "number m is negative";
		if (m == 0) {
			return n;
		} else if (n < m) {
			return gcd(m, n);
		} else {
			return gcd(m, n % m);
		}
	}

	/**
	 * Sorts an array in situ in ascending order using selection sort with recursion
	 * 
	 * @param sorted
	 * @param array
	 */

	static <T extends Comparable<T>> void selectionSort(ArrayList<T> array, int sorted) {
		assert array != null : "array should be initialized";
		if (sorted != array.size() - 1) {
			int j = indexOfSmallestValue(array, new Slice(sorted, array.size()), sorted);
			swap(array, sorted, j);
			selectionSort(array, ++sorted);
		}
	}

	/**
	 * Finds index of smallest value in array slice with recursion
	 * 
	 * @param array
	 * @param slice
	 * @param index
	 * @return index of smallest value
	 */
	static <T extends Comparable<T>> int indexOfSmallestValue(ArrayList<T> array, Slice slice, int index) {
		assert array != null : "Array should be initialized";
		assert slice.isValid() && slice.upto <= array.size() : "Slice should be valid";
		assert index >= 0 && index < array.size() : "Invalid index";
		if (slice.from == slice.upto)
			return index;
		else {
			if (array.get(slice.from).compareTo(array.get(index)) < 0)
				index = slice.from;
			index = indexOfSmallestValue(array, new Slice(slice.from + 1, slice.upto), index);
		}
		return index;
	}

	/**
	 * Swap two elements in an array
	 * 
	 * @param array
	 * @param i
	 * @param j
	 */
	private static <T extends Comparable<T>> void swap(ArrayList<T> array, int i, int j) {
		assert array != null : "Array should be initialized";
		assert i >= 0 && i < array.size() : "First index is invalid";
		assert j >= 0 && j < array.size() : "Second index is invalid";
		T help = array.get(i);
		array.set(i, array.get(j));
		array.set(j, help);
	}

	/**
	 * calculates the fibonacci number for the specified number
	 * 
	 * @param n
	 * @return fibonacci number
	 */

	static int fib(int n) {
		assert n >= 0 : "number is negative";
		if (n == 0 || n == 1)
			return 1;
		else
			return fib(n - 1) + fib(n - 2);
	}

	/**
	 * calculates the fibonacci number for the specified number, but faster
	 * 
	 * @param n
	 * @param fib
	 * @return value
	 */

	static int effFib(int n, int[] fib) {
		assert n >= 0 : "number is negative";
		assert fib != null : "array doesn't exist";
		if (n == 0 || n == 1)
			return 1;
		else if (fib[n] != 0)
			return fib[n];
		else {
			int value = effFib(n - 1, fib) + effFib(n - 2, fib);
			fib[n] = value;
			return value;
		}
	}

	/**
	 * calculates the fibonacci number for the specified number, but faster and with
	 * an array of length 3
	 * 
	 * @param n
	 * @param fib
	 * @param counter
	 * @return value
	 */

	static int fastFib(int n, int[] fib, int counter) {
		assert n >= 0 : "number is negative";
		assert counter >= 0 && counter < 3 : "counter out of bounds";
		assert fib != null : "array doesn't exist";
		if (n == 0 || n == 1)
			return 1;
		else if (fib[counter] != 0)
			return fib[counter];
		else {
			int value = fastFib(n - 1, fib, 1) + fastFib(n - 2, fib, 2);
			fib[2] = fib[1];
			fib[1] = value;
			return value;
		}
	}
}